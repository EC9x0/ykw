# D4LLA D4LLI — Paste Site

A dark, aesthetic paste-sharing site with media support. Built with Next.js 14.

## Features
- 📝 Create pastes with subject, description, and content
- 🎵 Upload MP3, M4A, WAV audio files
- 🎬 Upload MP4, MOV, WebM video files
- 🖼️ Upload images (JPG, PNG, GIF, WebP)
- 📎 Upload PDFs and other documents
- 🔒 Private (link-only) or public pastes
- ⏰ Expiring pastes (1h / 24h / 7d / 30d / never)
- 🔍 Full-text search across subjects, content, tags
- 👁️ View counter per paste
- 🏷️ Tags / labels

## Deploy to Vercel

1. Push to GitHub
2. Import in Vercel
3. Deploy (no env vars needed for basic setup)

> **Note:** The default in-memory store resets on each deployment. For persistent storage, swap `lib/store.ts` with Vercel KV:
> ```bash
> npm install @vercel/kv
> ```
> Then update store.ts to use `kv.get`, `kv.set`, `kv.hgetall`.

## Run locally
```bash
npm install
npm run dev
```

Open http://localhost:3000
