'use client'
import { useEffect, useState, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import Link from 'next/link'
import Navbar from '../Navbar'

interface PasteCard {
  id: string
  subject: string
  description: string
  author: string
  tags: string[]
  createdAt: string
  views: number
  content: string
  mediaFiles: { name: string; type: string }[]
}

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime()
  const m = Math.floor(diff / 60000)
  if (m < 1) return 'just now'
  if (m < 60) return `${m}m ago`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h}h ago`
  const d = Math.floor(h / 24)
  return `${d}d ago`
}

function SearchContent() {
  const searchParams = useSearchParams()
  const q = searchParams.get('q') || ''
  const [results, setResults] = useState<PasteCard[]>([])
  const [loading, setLoading] = useState(true)
  const [query, setQuery] = useState(q)

  useEffect(() => {
    if (!q) { setLoading(false); return }
    fetch(`/api/pastes?q=${encodeURIComponent(q)}`)
      .then(r => r.json())
      .then(setResults)
      .finally(() => setLoading(false))
  }, [q])

  return (
    <main style={{ padding: '48px 0 80px' }}>
      <div className="container">
        <div style={{ marginBottom: '40px' }}>
          <div className="badge badge-glow" style={{ marginBottom: '12px' }}>🔍 search</div>
          <h1 style={{ fontSize: '2rem', fontWeight: 800, marginBottom: '24px' }}>
            {q ? <>results for <span className="gradient-text">&quot;{q}&quot;</span></> : 'Search pastes'}
          </h1>

          {/* Search bar */}
          <form onSubmit={e => { e.preventDefault(); window.location.href = `/search?q=${encodeURIComponent(query)}` }}
            style={{ display: 'flex', gap: '10px', maxWidth: '500px' }}>
            <input className="input" value={query} onChange={e => setQuery(e.target.value)} placeholder="Search subjects, content, tags..." />
            <button type="submit" className="btn btn-primary" style={{ flexShrink: 0 }}>find</button>
          </form>
        </div>

        {loading ? (
          <div style={{ textAlign: 'center', padding: '60px', color: 'var(--text3)' }} className="mono">searching...</div>
        ) : !q ? (
          <div className="empty">
            <div className="empty-icon">🔍</div>
            <p>type something to search</p>
          </div>
        ) : results.length === 0 ? (
          <div className="empty">
            <div className="empty-icon">😶</div>
            <h3 style={{ marginBottom: '8px', color: 'var(--text2)' }}>nothing found</h3>
            <p>no pastes match &quot;{q}&quot;</p>
          </div>
        ) : (
          <>
            <p style={{ color: 'var(--text3)', marginBottom: '24px', fontSize: '0.9rem' }}>
              {results.length} result{results.length !== 1 ? 's' : ''}
            </p>
            <div className="paste-grid">
              {results.map(p => (
                <Link key={p.id} href={`/paste/${p.id}`} style={{ textDecoration: 'none', color: 'inherit' }}>
                  <div className="card card-hover" style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                    {p.tags.length > 0 && (
                      <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                        {p.tags.slice(0, 3).map(t => <span key={t} className="tag">{t}</span>)}
                      </div>
                    )}
                    <h3 style={{ fontSize: '1rem', fontWeight: 700 }}>{p.subject}</h3>
                    {p.description && (
                      <p style={{ color: 'var(--text2)', fontSize: '0.85rem',
                        display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                        {p.description}
                      </p>
                    )}
                    <div className="meta" style={{ paddingTop: '8px', borderTop: '1px solid var(--border)', marginTop: 'auto' }}>
                      <span style={{ color: 'var(--pink)', fontWeight: 600, fontSize: '0.8rem' }}>{p.author || 'anon'}</span>
                      <span>{timeAgo(p.createdAt)}</span>
                      <span>👁️ {p.views}</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </>
        )}
      </div>
    </main>
  )
}

export default function SearchPage() {
  return (
    <>
      <Navbar />
      <Suspense fallback={<div style={{ padding: '80px', textAlign: 'center', color: 'var(--text3)' }}>loading...</div>}>
        <SearchContent />
      </Suspense>
    </>
  )
}
