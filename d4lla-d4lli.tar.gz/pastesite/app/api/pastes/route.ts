import { NextRequest, NextResponse } from 'next/server'
import { v4 as uuidv4 } from 'uuid'
import { savePaste, getAllPastes, searchPastes } from '@/lib/store'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { subject, description, content, author, tags, mediaFiles, isPrivate, expiresIn } = body

    if (!subject?.trim()) {
      return NextResponse.json({ error: 'Subject is required' }, { status: 400 })
    }

    const id = uuidv4().replace(/-/g, '').substring(0, 12)
    const paste = {
      id,
      subject: subject.trim(),
      description: description?.trim() || '',
      content: content?.trim() || '',
      author: author?.trim() || 'anonymous',
      tags: Array.isArray(tags) ? tags.filter(Boolean) : [],
      mediaFiles: mediaFiles || [],
      createdAt: new Date().toISOString(),
      views: 0,
      isPrivate: !!isPrivate,
      expiresAt: expiresIn ? new Date(Date.now() + expiresIn * 1000).toISOString() : undefined,
    }

    savePaste(paste)
    return NextResponse.json({ id, url: `/paste/${id}` }, { status: 201 })
  } catch (err) {
    console.error(err)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const q = searchParams.get('q')
  const pastes = q ? searchPastes(q) : getAllPastes()
  // Don't send media data in list (too heavy)
  const safe = pastes.map(p => ({
    ...p,
    mediaFiles: p.mediaFiles.map(m => ({ name: m.name, type: m.type, size: m.size }))
  }))
  return NextResponse.json(safe)
}
