import { NextRequest, NextResponse } from 'next/server'
import { getPaste, incrementViews } from '@/lib/store'

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const paste = getPaste(params.id)
  if (!paste) {
    return NextResponse.json({ error: 'Not found' }, { status: 404 })
  }

  // Check expiry
  if (paste.expiresAt && new Date(paste.expiresAt) < new Date()) {
    return NextResponse.json({ error: 'This paste has expired' }, { status: 410 })
  }

  incrementViews(params.id)
  return NextResponse.json(paste)
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const paste = getPaste(params.id)
  if (!paste) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  // Simple delete (no auth for demo)
  const { store } = await import('@/lib/store')
  store.delete(params.id)
  return NextResponse.json({ ok: true })
}
