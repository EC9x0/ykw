import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'D4LLA D4LLI — Share Anything',
  description: 'type a name — universe reveals everything ✨',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
