'use client'
import { useState, useRef, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import Navbar from '../Navbar'

interface MediaFile {
  name: string
  type: string
  size: number
  data: string
}

const EXPIRY_OPTIONS = [
  { label: 'Never', value: 0 },
  { label: '1 Hour', value: 3600 },
  { label: '24 Hours', value: 86400 },
  { label: '7 Days', value: 604800 },
  { label: '30 Days', value: 2592000 },
]

function formatBytes(bytes: number) {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB'
}

function fileIcon(type: string) {
  if (type.startsWith('video/')) return '🎬'
  if (type.startsWith('audio/')) return '🎵'
  if (type.startsWith('image/')) return '🖼️'
  if (type.includes('pdf')) return '📄'
  return '📎'
}

export default function UploadPage() {
  const router = useRouter()
  const [subject, setSubject] = useState('')
  const [description, setDescription] = useState('')
  const [content, setContent] = useState('')
  const [author, setAuthor] = useState('')
  const [tags, setTags] = useState('')
  const [isPrivate, setIsPrivate] = useState(false)
  const [expiresIn, setExpiresIn] = useState(0)
  const [mediaFiles, setMediaFiles] = useState<MediaFile[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [dragOver, setDragOver] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFiles = useCallback(async (files: FileList | null) => {
    if (!files) return
    const arr = Array.from(files)
    for (const file of arr) {
      // 50MB limit
      if (file.size > 50 * 1024 * 1024) {
        setError(`${file.name} is too large (max 50MB)`)
        continue
      }
      const reader = new FileReader()
      reader.onload = () => {
        const data = (reader.result as string).split(',')[1]
        setMediaFiles(prev => [...prev, { name: file.name, type: file.type, size: file.size, data }])
      }
      reader.readAsDataURL(file)
    }
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(false)
    handleFiles(e.dataTransfer.files)
  }, [handleFiles])

  const removeMedia = (i: number) => {
    setMediaFiles(prev => prev.filter((_, idx) => idx !== i))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!subject.trim()) { setError('Subject is required'); return }
    setLoading(true)
    setError('')
    try {
      const res = await fetch('/api/pastes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subject, description, content, author,
          tags: tags.split(',').map(t => t.trim()).filter(Boolean),
          isPrivate, expiresIn: expiresIn || undefined,
          mediaFiles,
        })
      })
      const data = await res.json()
      if (!res.ok) { setError(data.error || 'Failed'); return }
      router.push(data.url)
    } catch {
      setError('Network error')
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <Navbar />
      <main style={{ padding: '48px 0 80px' }}>
        <div className="container-sm">
          {/* Header */}
          <div style={{ marginBottom: '40px' }}>
            <div className="badge badge-glow" style={{ marginBottom: '16px' }}>
              <span>✏️</span> new paste
            </div>
            <h1 style={{ fontSize: '2.4rem', fontWeight: 800 }}>
              <span className="gradient-text">Create</span>
              <span style={{ color: 'var(--text)' }}> a paste</span>
            </h1>
            <p style={{ color: 'var(--text2)', marginTop: '8px' }}>share text, media, anything — with anyone</p>
          </div>

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {/* Subject */}
            <div>
              <label className="label">Subject *</label>
              <input className="input" value={subject} onChange={e => setSubject(e.target.value)}
                placeholder="What's this about?" maxLength={200} required />
            </div>

            {/* Description */}
            <div>
              <label className="label">Description</label>
              <textarea className="input" value={description} onChange={e => setDescription(e.target.value)}
                placeholder="Add a description..." rows={3} maxLength={1000} />
            </div>

            {/* Content */}
            <div>
              <label className="label">Content / Text</label>
              <textarea className="input mono" value={content} onChange={e => setContent(e.target.value)}
                placeholder="paste your text, code, links, secrets..." rows={8} style={{ fontFamily: 'Space Mono, monospace', fontSize: '0.88rem' }} />
            </div>

            {/* Media Upload */}
            <div>
              <label className="label">Media Files</label>
              <div
                className={`upload-zone ${dragOver ? 'drag-over' : ''}`}
                onDrop={handleDrop}
                onDragOver={e => { e.preventDefault(); setDragOver(true) }}
                onDragLeave={() => setDragOver(false)}
                onClick={() => fileInputRef.current?.click()}
              >
                <div style={{ fontSize: '2.5rem', marginBottom: '12px' }}>🎵🎬🖼️</div>
                <p style={{ color: 'var(--text2)', marginBottom: '6px', fontWeight: 600 }}>Drop files here or click to browse</p>
                <p style={{ color: 'var(--text3)', fontSize: '0.82rem' }}>
                  Supports MP3, MP4, M4A, WAV, OGG, images, PDFs, and more · Max 50MB per file
                </p>
                <input ref={fileInputRef} type="file" multiple style={{ display: 'none' }}
                  accept="audio/*,video/*,image/*,.pdf,.txt,.doc,.docx"
                  onChange={e => handleFiles(e.target.files)} />
              </div>

              {/* File list */}
              {mediaFiles.length > 0 && (
                <div style={{ marginTop: '12px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {mediaFiles.map((f, i) => (
                    <div key={i} style={{
                      display: 'flex', alignItems: 'center', gap: '12px',
                      background: 'var(--surface2)', borderRadius: 'var(--radius-sm)',
                      padding: '10px 14px', border: '1px solid var(--border2)'
                    }}>
                      <span style={{ fontSize: '1.3rem' }}>{fileIcon(f.type)}</span>
                      <span style={{ flex: 1, fontSize: '0.88rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{f.name}</span>
                      <span style={{ color: 'var(--text3)', fontSize: '0.8rem', flexShrink: 0 }}>{formatBytes(f.size)}</span>
                      <button type="button" onClick={() => removeMedia(i)} style={{
                        background: 'none', border: 'none', color: 'var(--text3)', cursor: 'pointer',
                        fontSize: '1.1rem', padding: '2px 6px', flexShrink: 0
                      }}>×</button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Row: Author + Tags */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              <div>
                <label className="label">Author</label>
                <input className="input" value={author} onChange={e => setAuthor(e.target.value)}
                  placeholder="anonymous" maxLength={60} />
              </div>
              <div>
                <label className="label">Tags (comma-separated)</label>
                <input className="input" value={tags} onChange={e => setTags(e.target.value)}
                  placeholder="music, secret, funny" />
              </div>
            </div>

            {/* Row: Privacy + Expiry */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              <div>
                <label className="label">Visibility</label>
                <select className="input" value={isPrivate ? 'private' : 'public'}
                  onChange={e => setIsPrivate(e.target.value === 'private')}>
                  <option value="public">🌍 Public</option>
                  <option value="private">🔒 Private (link only)</option>
                </select>
              </div>
              <div>
                <label className="label">Expires</label>
                <select className="input" value={expiresIn} onChange={e => setExpiresIn(Number(e.target.value))}>
                  {EXPIRY_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </div>
            </div>

            {error && (
              <div style={{ background: 'rgba(255,95,109,0.1)', border: '1px solid rgba(255,95,109,0.3)', borderRadius: 'var(--radius-sm)', padding: '12px 16px', color: 'var(--coral)', fontSize: '0.9rem' }}>
                ⚠️ {error}
              </div>
            )}

            {/* Submit */}
            <div style={{ display: 'flex', gap: '12px', alignItems: 'center', marginTop: '8px' }}>
              <button type="submit" className="btn btn-coral" disabled={loading} style={{ fontSize: '1rem', padding: '14px 32px' }}>
                {loading ? '⏳ creating...' : '🚀 create paste'}
              </button>
              <button type="button" className="btn btn-ghost" onClick={() => { setSubject(''); setDescription(''); setContent(''); setMediaFiles([]) }}>
                clear
              </button>
            </div>
          </form>
        </div>
      </main>
    </>
  )
}
