'use client'
import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import Navbar from '../../Navbar'

interface MediaFile {
  name: string
  type: string
  size: number
  data?: string
}

interface Paste {
  id: string
  subject: string
  description: string
  content: string
  author: string
  tags: string[]
  mediaFiles: MediaFile[]
  createdAt: string
  views: number
  isPrivate: boolean
  expiresAt?: string
}

function formatBytes(b: number) {
  if (b < 1024) return b + ' B'
  if (b < 1024 * 1024) return (b / 1024).toFixed(1) + ' KB'
  return (b / (1024 * 1024)).toFixed(1) + ' MB'
}

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime()
  const m = Math.floor(diff / 60000)
  if (m < 1) return 'just now'
  if (m < 60) return `${m}m ago`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h}h ago`
  const d = Math.floor(h / 24)
  return `${d}d ago`
}

function MediaPlayer({ file }: { file: MediaFile }) {
  if (!file.data) return null
  const src = `data:${file.type};base64,${file.data}`

  if (file.type.startsWith('audio/')) {
    return (
      <div className="media-player">
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '12px' }}>
          <span style={{ fontSize: '1.5rem' }}>🎵</span>
          <div>
            <div style={{ fontWeight: 600, fontSize: '0.9rem' }}>{file.name}</div>
            <div style={{ color: 'var(--text3)', fontSize: '0.78rem' }}>{formatBytes(file.size)}</div>
          </div>
        </div>
        <audio controls src={src} />
      </div>
    )
  }

  if (file.type.startsWith('video/')) {
    return (
      <div className="media-player">
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '12px' }}>
          <span style={{ fontSize: '1.5rem' }}>🎬</span>
          <div>
            <div style={{ fontWeight: 600, fontSize: '0.9rem' }}>{file.name}</div>
            <div style={{ color: 'var(--text3)', fontSize: '0.78rem' }}>{formatBytes(file.size)}</div>
          </div>
        </div>
        <video controls src={src} />
      </div>
    )
  }

  if (file.type.startsWith('image/')) {
    return (
      <div className="media-player">
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '12px' }}>
          <span style={{ fontSize: '1.5rem' }}>🖼️</span>
          <div>
            <div style={{ fontWeight: 600, fontSize: '0.9rem' }}>{file.name}</div>
            <div style={{ color: 'var(--text3)', fontSize: '0.78rem' }}>{formatBytes(file.size)}</div>
          </div>
        </div>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={src} alt={file.name} style={{ maxWidth: '100%', borderRadius: 'var(--radius-sm)' }} />
      </div>
    )
  }

  return (
    <div className="media-player" style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
      <span style={{ fontSize: '1.5rem' }}>📎</span>
      <div style={{ flex: 1 }}>
        <div style={{ fontWeight: 600, fontSize: '0.9rem' }}>{file.name}</div>
        <div style={{ color: 'var(--text3)', fontSize: '0.78rem' }}>{formatBytes(file.size)}</div>
      </div>
      <a href={src} download={file.name} className="btn btn-ghost btn-sm">download</a>
    </div>
  )
}

export default function PastePage() {
  const params = useParams()
  const router = useRouter()
  const id = params.id as string
  const [paste, setPaste] = useState<Paste | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    fetch(`/api/pastes/${id}`)
      .then(r => {
        if (r.status === 404) throw new Error('Paste not found')
        if (r.status === 410) throw new Error('This paste has expired')
        if (!r.ok) throw new Error('Failed to load')
        return r.json()
      })
      .then(setPaste)
      .catch(e => setError(e.message))
      .finally(() => setLoading(false))
  }, [id])

  const copyUrl = () => {
    navigator.clipboard.writeText(window.location.href)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const copyContent = () => {
    if (paste?.content) {
      navigator.clipboard.writeText(paste.content)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  if (loading) return (
    <>
      <Navbar />
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '60vh', color: 'var(--text3)' }}>
        <div className="mono">loading paste...</div>
      </div>
    </>
  )

  if (error) return (
    <>
      <Navbar />
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '60vh', gap: '16px' }}>
        <div style={{ fontSize: '3rem' }}>💀</div>
        <h2 style={{ color: 'var(--text2)' }}>{error}</h2>
        <Link href="/" className="btn btn-primary">← go home</Link>
      </div>
    </>
  )

  if (!paste) return null

  return (
    <>
      <Navbar />
      <main style={{ padding: '40px 0 80px' }}>
        <div className="container-sm">
          {/* Header */}
          <div style={{ marginBottom: '32px' }}>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '16px', alignItems: 'center' }}>
              {paste.isPrivate && <span className="badge" style={{ background: 'rgba(255,95,109,0.1)', border: '1px solid rgba(255,95,109,0.3)', color: 'var(--coral)' }}>🔒 private</span>}
              {paste.tags.map(t => <span key={t} className="tag">{t}</span>)}
            </div>

            <h1 style={{ fontSize: 'clamp(1.6rem, 4vw, 2.4rem)', fontWeight: 800, marginBottom: '12px', lineHeight: 1.2 }}>
              {paste.subject}
            </h1>

            {paste.description && (
              <p style={{ color: 'var(--text2)', lineHeight: 1.7, marginBottom: '16px' }}>{paste.description}</p>
            )}

            <div className="meta">
              <span className="meta-item">👤 <span style={{ color: 'var(--pink)' }}>{paste.author || 'anonymous'}</span></span>
              <span className="meta-item">🕐 {timeAgo(paste.createdAt)}</span>
              <span className="meta-item">👁️ {paste.views} {paste.views === 1 ? 'view' : 'views'}</span>
              {paste.mediaFiles.length > 0 && (
                <span className="meta-item">📎 {paste.mediaFiles.length} file{paste.mediaFiles.length > 1 ? 's' : ''}</span>
              )}
            </div>
          </div>

          <hr className="divider" />

          {/* Content */}
          {paste.content && (
            <div style={{ marginBottom: '28px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                <label className="label" style={{ margin: 0 }}>content</label>
                <button onClick={copyContent} className="btn btn-ghost btn-sm">
                  {copied ? '✓ copied!' : 'copy'}
                </button>
              </div>
              <div className="content-block">{paste.content}</div>
            </div>
          )}

          {/* Media files */}
          {paste.mediaFiles.length > 0 && (
            <div style={{ marginBottom: '28px' }}>
              <label className="label" style={{ marginBottom: '12px' }}>media</label>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {paste.mediaFiles.map((f, i) => <MediaPlayer key={i} file={f} />)}
              </div>
            </div>
          )}

          <hr className="divider" />

          {/* Actions */}
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            <button onClick={copyUrl} className="btn btn-primary">
              {copied ? '✓ copied!' : '🔗 copy link'}
            </button>
            <Link href="/upload" className="btn btn-ghost">✏️ new paste</Link>
            <Link href="/recent" className="btn btn-ghost">← all pastes</Link>
          </div>
        </div>
      </main>
    </>
  )
}
