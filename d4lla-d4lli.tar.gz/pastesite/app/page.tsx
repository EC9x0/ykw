'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import Navbar from './Navbar'

export default function HomePage() {
  const [query, setQuery] = useState('')
  const router = useRouter()

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (query.trim()) router.push(`/search?q=${encodeURIComponent(query.trim())}`)
  }

  return (
    <>
      <Navbar />
      <main style={{ minHeight: '90vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '40px 24px' }}>
        {/* Badge */}
        <div className="badge badge-glow" style={{ marginBottom: '32px' }}>
          <span>🔥</span>
          <span>ZAARA BUND KHOLTE · YOU KNOW WHO · YKW</span>
        </div>

        {/* Hero title */}
        <h1 style={{ fontSize: 'clamp(3rem, 9vw, 7rem)', fontWeight: 800, textAlign: 'center', marginBottom: '16px', lineHeight: 1.05 }}>
          <span style={{ color: '#ff5f6d' }}>Find </span>
          <span className="gradient-text">D4LLA D4LLI</span>
        </h1>

        <p className="mono" style={{ color: 'var(--text2)', marginBottom: '48px', fontSize: '1rem', textAlign: 'center' }}>
          type a name — universe reveals everything ✨
        </p>

        {/* Search box */}
        <form onSubmit={handleSearch} style={{ width: '100%', maxWidth: '580px' }}>
          <div style={{
            background: 'var(--surface)',
            border: '1px solid var(--border2)',
            borderRadius: '16px',
            padding: '14px 14px',
            display: 'flex',
            gap: '10px',
            alignItems: 'center',
            boxShadow: '0 0 40px rgba(224,64,251,0.1)'
          }}>
            <input
              className="input"
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="type a name..."
              style={{ background: 'transparent', border: 'none', boxShadow: 'none', fontSize: '1.05rem' }}
            />
            <button type="button" style={{
              background: 'var(--surface2)',
              border: '1px solid var(--border2)',
              borderRadius: '10px',
              width: '40px', height: '40px',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer', color: 'var(--text2)', flexShrink: 0
            }}>
              ✏️
            </button>
            <button type="submit" className="btn btn-primary" style={{ flexShrink: 0, borderRadius: '10px' }}>
              find
            </button>
          </div>
          <p className="mono" style={{ textAlign: 'center', color: 'var(--text3)', fontSize: '0.78rem', marginTop: '12px' }}>
            tip: type the name you&apos;re thinking of 🤫
          </p>
        </form>

        {/* Quick actions */}
        <div style={{ display: 'flex', gap: '12px', marginTop: '48px', flexWrap: 'wrap', justifyContent: 'center' }}>
          <Link href="/upload" className="btn btn-ghost">
            📝 new paste
          </Link>
          <Link href="/recent" className="btn btn-ghost">
            🕐 recent pastes
          </Link>
        </div>

        {/* Footer note */}
        <div style={{ position: 'absolute', bottom: '24px', color: 'var(--text3)', fontSize: '0.75rem' }} className="mono">
          · ADMIN ·
        </div>
      </main>
    </>
  )
}
