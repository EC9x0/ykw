'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

export default function Navbar() {
  const path = usePathname()
  return (
    <nav className="nav">
      <Link href="/" className="nav-logo gradient-text">D4LLA D4LLI</Link>
      <div className="nav-links">
        <Link href="/" className={`nav-link ${path === '/' ? 'active' : ''}`}>home</Link>
        <Link href="/recent" className={`nav-link ${path === '/recent' ? 'active' : ''}`}>recent</Link>
        <Link href="/upload" className="btn btn-coral btn-sm">+ new paste</Link>
      </div>
    </nav>
  )
}
