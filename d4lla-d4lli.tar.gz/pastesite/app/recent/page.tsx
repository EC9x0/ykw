'use client'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import Navbar from '../Navbar'

interface PasteCard {
  id: string
  subject: string
  description: string
  author: string
  tags: string[]
  createdAt: string
  views: number
  isPrivate: boolean
  mediaFiles: { name: string; type: string; size: number }[]
  content: string
}

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime()
  const m = Math.floor(diff / 60000)
  if (m < 1) return 'just now'
  if (m < 60) return `${m}m ago`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h}h ago`
  const d = Math.floor(h / 24)
  return `${d}d ago`
}

function mediaIcons(files: { type: string }[]) {
  return files.map(f => {
    if (f.type.startsWith('audio/')) return '🎵'
    if (f.type.startsWith('video/')) return '🎬'
    if (f.type.startsWith('image/')) return '🖼️'
    return '📎'
  }).join(' ')
}

export default function RecentPage() {
  const [pastes, setPastes] = useState<PasteCard[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/pastes')
      .then(r => r.json())
      .then(setPastes)
      .finally(() => setLoading(false))
  }, [])

  return (
    <>
      <Navbar />
      <main style={{ padding: '48px 0 80px' }}>
        <div className="container">
          {/* Header */}
          <div style={{ marginBottom: '40px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: '16px' }}>
            <div>
              <div className="badge badge-glow" style={{ marginBottom: '12px' }}>
                <span>🕐</span> recent pastes
              </div>
              <h1 style={{ fontSize: '2.2rem', fontWeight: 800 }}>
                <span className="gradient-text">Latest</span>
                <span style={{ color: 'var(--text)' }}> drops</span>
              </h1>
              <p style={{ color: 'var(--text3)', marginTop: '6px', fontSize: '0.9rem' }}>
                {pastes.length} public paste{pastes.length !== 1 ? 's' : ''}
              </p>
            </div>
            <Link href="/upload" className="btn btn-coral">+ new paste</Link>
          </div>

          {loading ? (
            <div style={{ textAlign: 'center', padding: '80px', color: 'var(--text3)' }} className="mono">
              loading...
            </div>
          ) : pastes.length === 0 ? (
            <div className="empty">
              <div className="empty-icon">📭</div>
              <h3 style={{ marginBottom: '8px', color: 'var(--text2)' }}>No pastes yet</h3>
              <p style={{ marginBottom: '24px' }}>Be the first to share something</p>
              <Link href="/upload" className="btn btn-primary">create first paste</Link>
            </div>
          ) : (
            <div className="paste-grid">
              {pastes.map(p => (
                <Link key={p.id} href={`/paste/${p.id}`} style={{ textDecoration: 'none', color: 'inherit' }}>
                  <div className="card card-hover" style={{ height: '100%', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    {/* Tags */}
                    {p.tags.length > 0 && (
                      <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                        {p.tags.slice(0, 3).map(t => <span key={t} className="tag">{t}</span>)}
                      </div>
                    )}

                    {/* Subject */}
                    <h3 style={{ fontSize: '1.05rem', fontWeight: 700, lineHeight: 1.3, color: 'var(--text)' }}>
                      {p.subject}
                    </h3>

                    {/* Description */}
                    {p.description && (
                      <p style={{ color: 'var(--text2)', fontSize: '0.87rem', lineHeight: 1.6, flex: 1,
                        display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                        {p.description}
                      </p>
                    )}

                    {/* Content preview */}
                    {!p.description && p.content && (
                      <p style={{ color: 'var(--text3)', fontSize: '0.82rem', fontFamily: 'Space Mono, monospace', flex: 1,
                        display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                        {p.content}
                      </p>
                    )}

                    {/* Media badges */}
                    {p.mediaFiles.length > 0 && (
                      <div style={{ fontSize: '1rem' }}>{mediaIcons(p.mediaFiles)}</div>
                    )}

                    {/* Meta */}
                    <div className="meta" style={{ marginTop: 'auto', paddingTop: '8px', borderTop: '1px solid var(--border)' }}>
                      <span style={{ color: 'var(--pink)', fontWeight: 600, fontSize: '0.8rem' }}>{p.author || 'anon'}</span>
                      <span>{timeAgo(p.createdAt)}</span>
                      <span>👁️ {p.views}</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </main>
    </>
  )
}
