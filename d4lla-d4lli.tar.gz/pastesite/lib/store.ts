// In-memory store for dev; on Vercel use KV or a DB.
// For easy Vercel deploy, we use a simple JSON file approach via filesystem (tmp) 
// or you can swap this for Vercel KV / PlanetScale / Supabase.

export interface Paste {
  id: string;
  subject: string;
  description: string;
  content: string;
  author?: string;
  tags?: string[];
  mediaFiles: MediaFile[];
  createdAt: string;
  views: number;
  isPrivate: boolean;
  expiresAt?: string;
}

export interface MediaFile {
  name: string;
  type: string;
  size: number;
  data: string; // base64
  url?: string;
}

// Global in-memory store (works for single instance; replace with DB for prod)
declare global {
  var __pastes: Map<string, Paste> | undefined;
}

if (!global.__pastes) {
  global.__pastes = new Map();
}

export const store = global.__pastes;

export function getPaste(id: string): Paste | undefined {
  return store.get(id);
}

export function savePaste(paste: Paste): void {
  store.set(paste.id, paste);
}

export function getAllPastes(): Paste[] {
  return Array.from(store.values())
    .filter(p => !p.isPrivate)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export function searchPastes(query: string): Paste[] {
  const q = query.toLowerCase();
  return Array.from(store.values())
    .filter(p => !p.isPrivate && (
      p.subject.toLowerCase().includes(q) ||
      p.description.toLowerCase().includes(q) ||
      p.content.toLowerCase().includes(q) ||
      p.author?.toLowerCase().includes(q) ||
      p.tags?.some(t => t.toLowerCase().includes(q))
    ))
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export function incrementViews(id: string): void {
  const paste = store.get(id);
  if (paste) {
    paste.views++;
    store.set(id, paste);
  }
}
